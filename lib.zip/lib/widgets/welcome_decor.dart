import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/colors.dart';

/// Slow-drifting ambient particles — small green/gold dots that rise and
/// fade in a loop. Purely atmospheric: reinforces "currency in motion"
/// without competing with the logo's own arrow animation, since these
/// move much slower and are much fainter. [progress] is 0..1 looping;
/// each particle's phase is offset by its own seed so they don't move in
/// unison.
class ParticleFieldPainter extends CustomPainter {
  final double progress;
  final int count;
  ParticleFieldPainter({required this.progress, this.count = 14});

  @override
  void paint(Canvas canvas, Size size) {
    final rnd = math.Random(7); // fixed seed — stable layout across frames
    for (int i = 0; i < count; i++) {
      final seed = rnd.nextDouble();
      final startX = rnd.nextDouble() * size.width;
      final speed = 0.55 + rnd.nextDouble() * 0.9;
      final radius = 1.4 + rnd.nextDouble() * 2.2;
      final isGreen = i.isEven;

      // Each particle loops independently via its own phase offset so
      // the field never looks like one synchronized pulse.
      final t = (progress * speed + seed) % 1.0;
      final y = size.height * (1 - t);
      final x = startX + math.sin(t * math.pi * 2 + seed * 10) * 14;

      // Fade in, hold, fade out — avoids particles popping in/out at the
      // top/bottom edges.
      final opacity = (t < 0.15 ? t / 0.15 : (t > 0.8 ? (1 - t) / 0.2 : 1.0))
          .clamp(0.0, 1.0);

      final paint = Paint()
        ..color = (isGreen ? AppColors.green : AppColors.goldDark)
            .withValues(alpha: 0.10 * opacity);
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant ParticleFieldPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/// Wraps [child] with a diagonal light sweep that passes across it every
/// few seconds — a quieter cousin of the CTA's breathing glow, meant to
/// catch the eye without looking like a loading state. [progress] is
/// 0..1; sweep only occupies a portion of the cycle so it reads as an
/// occasional glint rather than continuous motion.
class ShimmerSweep extends StatelessWidget {
  final double progress;
  final BorderRadius borderRadius;
  final Widget child;
  const ShimmerSweep({
    super.key,
    required this.progress,
    required this.borderRadius,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    // Sweep runs during the first 35% of the cycle, then stays parked
    // off-screen for the rest — an occasional glint, not a scan line.
    final sweepT = (progress / 0.35).clamp(0.0, 1.0);
    final dx = -1.6 + sweepT * 3.2;
    final active = progress <= 0.35;
    final opacity = active ? (1 - (sweepT - 0.5).abs() * 2).clamp(0.0, 1.0) * 0.5 : 0.0;

    return ClipRRect(
      borderRadius: borderRadius,
      child: Stack(
        children: [
          child,
          // Always mounted — never conditionally added/removed from the
          // tree. Toggling a whole subtree in and out every animation
          // frame (this used to be `if (progress <= 0.35) ...`) forces
          // constant RenderObject creation/disposal, which on Flutter
          // Windows desktop can surface as MouseTracker/RenderBox
          // assertion failures the moment the pointer hovers this
          // widget mid-rebuild. Parking it at opacity 0 instead keeps
          // one stable RenderObject for the whole loop; only paint
          // changes, layout doesn't churn.
          IgnorePointer(
            child: Opacity(
              opacity: opacity,
              child: Align(
                alignment: Alignment(dx, 0),
                child: FractionallySizedBox(
                  widthFactor: 0.28,
                  heightFactor: 1.6,
                  child: Transform.rotate(
                    angle: 0.5,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withValues(alpha: 0.0),
                            Colors.white.withValues(alpha: 0.55),
                            Colors.white.withValues(alpha: 0.0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A dashed circle, used to build the concentric "exchange dial" behind
/// the logo. Deliberately hand-rolled (dart:ui has no dash-path helper)
/// so it stays dependency-free.
class DashedRingPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final int dashCount;
  final double dashFraction; // 0..1 of each segment that's "on"
  final double rotation; // radians

  DashedRingPainter({
    required this.color,
    this.strokeWidth = 1.4,
    this.dashCount = 28,
    this.dashFraction = 0.55,
    this.rotation = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2 - strokeWidth;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    final segment = (2 * math.pi) / dashCount;
    final on = segment * dashFraction;
    final rect = Rect.fromCircle(center: center, radius: radius);

    for (int i = 0; i < dashCount; i++) {
      final start = rotation + i * segment;
      canvas.drawArc(rect, start, on, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant DashedRingPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.rotation != rotation;
}

/// Very faint dot-grid, the texture of security paper / thermal receipt
/// stock. Static, cheap, and only meant to be felt, not seen directly.
class DotGridPainter extends CustomPainter {
  final Color color;
  final double spacing;
  final double dotRadius;

  DotGridPainter({
    required this.color,
    this.spacing = 22,
    this.dotRadius = 1.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    for (double y = spacing / 2; y < size.height; y += spacing) {
      for (double x = spacing / 2; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant DotGridPainter oldDelegate) => false;
}

/// The welcome screen's call to action, styled like a torn ticket stub —
/// two punched notches at the ends — since this kiosk's whole job is
/// handing people a token of value. Deliberately distinct from the plain
/// [PrimaryButton] used mid-flow.
class TicketButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final double fontSize;
  final double iconSize;
  final double paddingH;
  final double paddingV;
  final double radius;
  final ValueChanged<bool>? onHighlightChanged;
  const TicketButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.fontSize = 14,
    this.iconSize = 18,
    this.paddingH = 30,
    this.paddingV = 16,
    this.radius = 14,
    this.onHighlightChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(radius),
        onTap: onPressed,
        // Press-state feedback lives here, not in a second GestureDetector
        // wrapped around this widget — stacking two tap recognizers over
        // the same button competes in the same gesture arena, and which
        // one "wins" a given tap isn't guaranteed to stay consistent
        // across rebuilds (it can flip after the widget tree is torn
        // down and rebuilt, e.g. cycling through a full transaction and
        // back to this screen) — silently eating taps that look like
        // they should work. One recognizer, no ambiguity.
        onHighlightChanged: onHighlightChanged,
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [AppColors.green, Color(0xFF255E29)],
            ),
            borderRadius: BorderRadius.circular(radius),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: paddingH, vertical: paddingV),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: fontSize,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.1,
                  ),
                ),
                SizedBox(width: paddingH * 0.3),
                Icon(Icons.arrow_forward_rounded, color: Colors.white, size: iconSize),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// A short hairline-flanked label, e.g. "— SMART CURRENCY EXCHANGE —",
/// used in place of a plain caption for a more considered, signage-like
/// feel.
class FlankedLabel extends StatelessWidget {
  final String text;
  final double fontSize;
  final double gap;
  final double ruleWidth;
  const FlankedLabel({
    super.key,
    required this.text,
    this.fontSize = 11,
    this.gap = 10,
    this.ruleWidth = 18,
  });

  @override
  Widget build(BuildContext context) {
    final rule = Container(
      width: ruleWidth,
      height: 1,
      color: AppColors.textSecondary.withValues(alpha: 0.35),
    );
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        rule,
        SizedBox(width: gap),
        Text(
          text,
          style: TextStyle(
            fontSize: fontSize,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
            letterSpacing: 2.4,
          ),
        ),
        SizedBox(width: gap),
        rule,
      ],
    );
  }
}
