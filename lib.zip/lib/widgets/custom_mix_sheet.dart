import 'package:flutter/material.dart';

import '../theme/colors.dart';
import '../state/kiosk_controller.dart';
import 'buttons.dart';

/// Matches the admin app's own low-inventory alert threshold — a
/// denomination at or below this count gets flagged in the picker so the
/// customer can see it's running low before they build a mix around it.
const _lowStockThreshold = 20;

/// Lets the customer build their own denomination mix instead of taking
/// the greedy Quick mix. Each row is capped at what's actually available
/// (in stock and not admin-disabled) via [KioskController]'s live
/// inventory cache — same source of truth [KioskController.computeBreakdown]
/// uses — so a custom mix can never promise coins/bills the kiosk doesn't
/// have. Confirm only enables once the counts sum exactly to [payout].
///
/// Returns the chosen breakdown via Navigator.pop, or null if dismissed.
class CustomMixSheet extends StatefulWidget {
  final int payout;
  final KioskController controller;
  const CustomMixSheet({super.key, required this.payout, required this.controller});

  @override
  State<CustomMixSheet> createState() => _CustomMixSheetState();
}

class _CustomMixSheetState extends State<CustomMixSheet> {
  late final Map<int, int> _counts = {
    for (final d in kDispenseDenominations) d: 0,
  };

  int get _total =>
      _counts.entries.fold(0, (sum, e) => sum + e.key * e.value);

  int _availableFor(int denom) =>
      widget.controller.firebase.availableQty(denom.toString(), denom >= 20);

  void _adjust(int denom, int delta) {
    final next = _counts[denom]! + delta;
    final remaining = widget.payout - _total;
    if (delta > 0) {
      // Can't add more than what's in stock, and no point letting the
      // total overshoot the payout — cap the increment at whichever is
      // tighter. The button itself is disabled once either limit is hit
      // (see canIncrement below), so these are just a safety net.
      if (next > _availableFor(denom)) return;
      if (denom > remaining) return;
    }
    if (next < 0) return;
    setState(() => _counts[denom] = next);
  }

  @override
  Widget build(BuildContext context) {
    final remaining = widget.payout - _total;
    final canConfirm = remaining == 0 && _total > 0;

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 18,
          bottom: MediaQuery.of(context).viewInsets.bottom + 18,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Build your own mix',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                Text(
                  '₱${widget.payout}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: AppColors.goldDark,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              remaining == 0
                  ? uppercaseLabel('Ready to confirm')
                  : uppercaseLabel('₱$remaining left to allocate'),
              style: TextStyle(
                fontSize: 11,
                letterSpacing: 1.0,
                fontWeight: FontWeight.w700,
                color: remaining == 0 ? AppColors.green : AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 12),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 320),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    for (final denom in kDispenseDenominations)
                      // Only offer denominations that could actually fit
                      // in this payout at all — no point showing a ₱50
                      // option for a ₱20 breakdown, it can never be used.
                      if (_availableFor(denom) > 0 && denom <= widget.payout)
                        _DenomRow(
                          denom: denom,
                          count: _counts[denom]!,
                          available: _availableFor(denom),
                          atStockCap: _counts[denom]! >= _availableFor(denom),
                          canIncrement: _counts[denom]! < _availableFor(denom) &&
                              denom <= remaining,
                          onDecrement: () => _adjust(denom, -1),
                          onIncrement: () => _adjust(denom, 1),
                        ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 44,
              child: PrimaryButton(
                label: uppercaseLabel(
                  canConfirm ? 'Confirm this mix' : 'Allocate the full amount',
                ),
                onPressed: canConfirm
                    ? () => Navigator.of(context).pop(
                          Map<int, int>.fromEntries(
                            _counts.entries.where((e) => e.value > 0),
                          ),
                        )
                    : () {},
                padding: EdgeInsets.zero,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DenomRow extends StatelessWidget {
  final int denom;
  final int count;
  final int available;
  final bool atStockCap;
  final bool canIncrement;
  final VoidCallback onDecrement;
  final VoidCallback onIncrement;

  const _DenomRow({
    required this.denom,
    required this.count,
    required this.available,
    required this.atStockCap,
    required this.canIncrement,
    required this.onDecrement,
    required this.onIncrement,
  });

  @override
  Widget build(BuildContext context) {
    final isBill = denom >= 20;
    // Deliberately no exact stock numbers anywhere in this row — a public
    // kiosk screen shouldn't broadcast exactly how much cash sits in each
    // hopper. Instead: a quiet "limited stock" heads-up while there's
    // still room to pick something else, and a clearer "that's all we
    // have" the moment they've actually taken everything available — the
    // stepper is hard-capped underneath either way (see canIncrement).
    final isLow = available <= _lowStockThreshold && available != 999999;
    final String? note = atStockCap
        ? "that's all we have"
        : (isLow ? 'limited stock' : null);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isBill ? AppColors.greenTint : AppColors.goldTint,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(
                  isBill ? Icons.payments_outlined : Icons.circle_outlined,
                  size: 16,
                  color: isBill ? AppColors.green : AppColors.goldDark,
                ),
              ),
              if (note != null)
                Positioned(
                  top: -3,
                  right: -3,
                  child: Container(
                    width: 13,
                    height: 13,
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(
                      color: AppColors.goldDark,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.priority_high, size: 9, color: Colors.white),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '₱$denom',
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          Text(
            // Deliberately no exact count shown — a public kiosk screen
            // isn't the place to broadcast exactly how much cash sits in
            // each hopper. The stepper is still hard-capped at true
            // availability underneath (see canIncrement); this just gives
            // a heads-up, worded differently depending on whether there's
            // still some left or the denomination is fully spoken for.
            note ?? '',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: atStockCap ? AppColors.textSecondary : AppColors.goldDark,
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.remove_circle_outline),
            color: AppColors.green,
            onPressed: count > 0 ? onDecrement : null,
          ),
          SizedBox(
            width: 22,
            child: Text(
              '$count',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            color: AppColors.green,
            onPressed: canIncrement ? onIncrement : null,
          ),
        ],
      ),
    );
  }
}
