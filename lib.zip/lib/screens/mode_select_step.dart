import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/colors.dart';
import '../state/kiosk_controller.dart';
import '../widgets/buttons.dart';

class ModeSelectStep extends StatefulWidget {
  const ModeSelectStep({super.key});

  @override
  State<ModeSelectStep> createState() => _ModeSelectStepState();
}

class _ModeSelectStepState extends State<ModeSelectStep>
    with TickerProviderStateMixin {
  late final AnimationController _entrance = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  )..forward();

  Animation<double> _cardAnim(double start) => CurvedAnimation(
        parent: _entrance,
        curve: Interval(start, (start + 0.6).clamp(0.0, 1.0), curve: Curves.easeOutCubic),
      );

  @override
  void dispose() {
    _entrance.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.read<KioskController>();
    final leftAnim = _cardAnim(0.0);
    final rightAnim = _cardAnim(0.15);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'What would you like to do?',
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.4,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          uppercaseLabel('Select an exchange mode'),
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            letterSpacing: 1.4,
          ),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: Row(
            children: [
              Expanded(
                child: FadeTransition(
                  opacity: leftAnim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(-0.08, 0),
                      end: Offset.zero,
                    ).animate(leftAnim),
                    child: _ModeCard(
                      icon: Icons.call_split_rounded,
                      accent: AppColors.green,
                      accentTint: AppColors.greenTint,
                      title: 'Pabarya',
                      description: 'Break a bill into coins and smaller cash',
                      footnote: '₱20 total minimum',
                      onTap: () => controller.selectMode(ExchangeMode.pabarya),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: FadeTransition(
                  opacity: rightAnim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0.08, 0),
                      end: Offset.zero,
                    ).animate(rightAnim),
                    child: _ModeCard(
                      icon: Icons.call_merge_rounded,
                      accent: AppColors.goldDark,
                      accentTint: AppColors.goldTint,
                      title: 'Pabuo',
                      description: 'Combine coins and bills into a bigger bill',
                      footnote: 'Any mix accepted',
                      onTap: () => controller.selectMode(ExchangeMode.pabuo),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ModeCard extends StatefulWidget {
  final IconData icon;
  final Color accent;
  final Color accentTint;
  final String title;
  final String description;
  final String footnote;
  final VoidCallback onTap;

  const _ModeCard({
    required this.icon,
    required this.accent,
    required this.accentTint,
    required this.title,
    required this.description,
    required this.footnote,
    required this.onTap,
  });

  @override
  State<_ModeCard> createState() => _ModeCardState();
}

class _ModeCardState extends State<_ModeCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: _pressed ? 0.97 : 1.0,
      duration: const Duration(milliseconds: 110),
      curve: Curves.easeOut,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: widget.onTap,
          // Single tap recognizer driving both the action and the press
          // feedback — avoids stacking a second GestureDetector on top,
          // which is what caused the welcome screen's CTA to silently
          // stop responding after a rebuild (see TicketButton).
          onHighlightChanged: (v) => setState(() => _pressed = v),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Colored header band instead of a barely-visible 4px top
              // line — this is what was making the cards read as mostly
              // dead white space. A soft gradient plus a large icon badge
              // gives each mode real visual identity at a glance, and a
              // faint oversized watermark icon adds a bit of depth
              // without competing with the real one.
              Expanded(
                flex: 5,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        widget.accentTint,
                        widget.accentTint.withValues(alpha: 0.35),
                      ],
                    ),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        right: -18,
                        bottom: -22,
                        child: Icon(
                          widget.icon,
                          size: 96,
                          color: widget.accent.withValues(alpha: 0.10),
                        ),
                      ),
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: widget.accent.withValues(alpha: 0.22),
                              blurRadius: 16,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Icon(widget.icon, size: 27, color: widget.accent),
                      ),
                    ],
                  ),
                ),
              ),
              // Body
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.title,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.2,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            widget.description,
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppColors.textSecondary,
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 9, vertical: 5),
                            decoration: BoxDecoration(
                              color: widget.accentTint,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              widget.footnote,
                              style: TextStyle(
                                fontSize: 11,
                                color: widget.accent,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: widget.accent,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.arrow_forward_rounded,
                              size: 14,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
