import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/colors.dart';
import '../state/kiosk_controller.dart';
import '../widgets/buttons.dart';
import '../widgets/custom_mix_sheet.dart';

class SelectOutputStep extends StatelessWidget {
  const SelectOutputStep({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.read<KioskController>();
    final amount =
        context.select<KioskController, int>((c) => c.amountInsertedPesos);
    final fee = context.select<KioskController, int>((c) => c.feeAmount);
    final payout = context.select<KioskController, int>((c) => c.payoutAmount);
    // Stock- and disabled-denomination aware, and computed on the
    // post-fee payout — skips anything the admin app has pulled offline
    // or that's run out, using other denominations to still cover the
    // amount actually owed. See KioskController.computeBreakdown.
    final quickMix = controller.computeBreakdown(payout);
    final quickMixLabel = quickMix.entries
        .map((e) => '${e.value}x ₱${e.key}')
        .join(', ');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '₱${amount.toStringAsFixed(2)}',
          style: const TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.4,
            color: AppColors.goldDark,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          uppercaseLabel('Received — choose your output'),
          style: const TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            letterSpacing: 1.0,
          ),
        ),
        if (fee > 0) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.goldTint,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.info_outline, size: 14, color: AppColors.goldDark),
                const SizedBox(width: 6),
                Text(
                  'Service fee ₱$fee deducted — you\'ll receive ₱$payout',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.goldDark,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        Expanded(
          child: Row(
            children: [
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => controller.confirmOutput(quickMix),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.dark,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          top: -16,
                          left: -16,
                          right: -16,
                          child: Container(height: 4, color: AppColors.green),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Quick mix',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.2,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              quickMixLabel.isEmpty ? '—' : quickMixLabel,
                              style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.mutedOnDark,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () async {
                    final customMix = await showModalBottomSheet<Map<int, int>>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                      ),
                      builder: (_) => CustomMixSheet(payout: payout, controller: controller),
                    );
                    if (customMix != null && context.mounted) {
                      controller.confirmOutput(customMix);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: AppColors.screenBorder),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          top: -16,
                          left: -16,
                          right: -16,
                          child: Container(height: 4, color: AppColors.goldDark),
                        ),
                        const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Custom mix',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.2,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            Text(
                              'Choose your own combination',
                              style: TextStyle(
                                fontSize: 12,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          height: 42,
          child: PrimaryButton(
            label: uppercaseLabel('Confirm quick mix'),
            onPressed: () => controller.confirmOutput(quickMix),
            padding: EdgeInsets.zero,
          ),
        ),
      ],
    );
  }
}
